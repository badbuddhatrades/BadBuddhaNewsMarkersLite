#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddha_NewsMarkers_Lite[] cacheBadBuddha_NewsMarkers_Lite;

		
		public BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			return BadBuddha_NewsMarkers_Lite(Input, autoReloadMinutes, flagFolderName, showVerticalLines, vLineOpacityPct, vLineThicknessPx);
		}


		
		public BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(ISeries<double> input, int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			if (cacheBadBuddha_NewsMarkers_Lite != null)
				for (int idx = 0; idx < cacheBadBuddha_NewsMarkers_Lite.Length; idx++)
					if (cacheBadBuddha_NewsMarkers_Lite[idx].AutoReloadMinutes == autoReloadMinutes && cacheBadBuddha_NewsMarkers_Lite[idx].FlagFolderName == flagFolderName && cacheBadBuddha_NewsMarkers_Lite[idx].ShowVerticalLines == showVerticalLines && cacheBadBuddha_NewsMarkers_Lite[idx].VLineOpacityPct == vLineOpacityPct && cacheBadBuddha_NewsMarkers_Lite[idx].VLineThicknessPx == vLineThicknessPx && cacheBadBuddha_NewsMarkers_Lite[idx].EqualsInput(input))
						return cacheBadBuddha_NewsMarkers_Lite[idx];
			return CacheIndicator<BadBuddha_NewsMarkers_Lite>(new BadBuddha_NewsMarkers_Lite(){ AutoReloadMinutes = autoReloadMinutes, FlagFolderName = flagFolderName, ShowVerticalLines = showVerticalLines, VLineOpacityPct = vLineOpacityPct, VLineThicknessPx = vLineThicknessPx }, input, ref cacheBadBuddha_NewsMarkers_Lite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			return indicator.BadBuddha_NewsMarkers_Lite(Input, autoReloadMinutes, flagFolderName, showVerticalLines, vLineOpacityPct, vLineThicknessPx);
		}


		
		public Indicators.BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(ISeries<double> input , int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			return indicator.BadBuddha_NewsMarkers_Lite(input, autoReloadMinutes, flagFolderName, showVerticalLines, vLineOpacityPct, vLineThicknessPx);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			return indicator.BadBuddha_NewsMarkers_Lite(Input, autoReloadMinutes, flagFolderName, showVerticalLines, vLineOpacityPct, vLineThicknessPx);
		}


		
		public Indicators.BadBuddha_NewsMarkers_Lite BadBuddha_NewsMarkers_Lite(ISeries<double> input , int autoReloadMinutes, string flagFolderName, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx)
		{
			return indicator.BadBuddha_NewsMarkers_Lite(input, autoReloadMinutes, flagFolderName, showVerticalLines, vLineOpacityPct, vLineThicknessPx);
		}

	}
}

#endregion
